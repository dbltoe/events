<?php
/**
 * @package Information Box for Scheduled Events 1.6
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: events_extra_tables_filenames.php 3001 2012-01-18 11:45:06Z dbltoe $
 */

// define the extra table filenames
  define('TABLE_EVENTS', 'zen_events');
?>